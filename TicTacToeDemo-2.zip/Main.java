import java.util.*; 

class Main {
  /*
   * Additional features to add
   *   - "play again?"
   *   - input validation and retries
   *   - better win condition checking
   *   - positional input instead of x,y
   *   - detecting draws sooner
   */

  public static void main(String[] args) {
    int [][] board = new int[3][3];
    int moveCount = 0;
    boolean winCond = false;
    int player = playersTurn(moveCount);
    Scanner movePrompt = new Scanner(System.in);
    printBoardinit(board);
    while (!winCond && moveCount < 9){
      moveCount++;
      player = playersTurn(moveCount);
      makeMove(board, movePrompt, player);
      winCond = someoneWon(board);
      printBoard(board);
    }
    if(winCond){
      System.out.println(String.format("Player %d has won!", player));
    } else {
      System.out.println("Game has ended in a draw.");
    }
  }

  private static int playersTurn(int moveCount) {
    if(moveCount % 2 == 1){
      return 1;
    } else {
      return 2;
    }
  }

  private static void makeMove(int[][] board, Scanner input, int player) {
    boolean moveDone = false;
    while (!moveDone){
      System.out.println(String.format("It is player %d's turn. Please select a move using 1-9.", player));
      int moveSpace = input.nextInt();
      if(moveSpace < 1 || moveSpace > 9){
        System.out.println("This space does not exist; please make a valid move");
        continue;
      }
      int row = (moveSpace-1) / 3;
      int col = (moveSpace-1) % 3;
      if (board[row][col] != 0){
        System.out.println("That space is occupied; please make a valid move.");
        continue;
      }
      if(player == 1){
        board[row][col] = 1;
      } else {
        board[row][col] = 2;
      }
      moveDone = true;
    }
  }

  private static boolean someoneWon(int[][] board) {
    for (int i = 0; i < 3; i++){
      if (board[i][0] == board[i][1] && board[i][1] == board[i][2] &&board[i][0] !=0){
        return true;
      }
    }
    for (int j = 0; j < 3; j++){
      if (board[0][j] == board[1][j] && board[1][j] == board[2][j] &&board[0][j]!=0){
        return true;
      }
    }
    if(board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != 0){
      return true;
    }
    if(board[0][2] == board [1][1] && board[1][1] == board[2][0] && board[0][2] != 0){
      return true;
    }
    return false;
  }

  private static void printBoard(int[][] board) {
    // How will you see all the moves
    // for each player on the console? 
    for (int i = 0; i < 3; i++) {
      System.out.print(" ");
      printCell(board[i][0]); 
      System.out.print(" ║ ");
      printCell(board[i][1]); 
      System.out.print(" ║ ");
      printCell(board[i][2]); 
      System.out.println();
      if (i != 2) {
        System.out.println("═══╬═══╬═══");
      }
    }
  }
 private static void printBoardinit(int[][] board) {
    // How will you see all the moves
    // for each player on the console? 
    for (int i = 0; i < 3; i++) {
      System.out.print(" ");
      System.out.print(3*i+1); 
      System.out.print(" ║ ");
      System.out.print(3*i+2); 
      System.out.print(" ║ ");
      System.out.print(3*i+3); 
      System.out.println();
      if (i != 2) {
        System.out.println("═══╬═══╬═══");
      }
    }
  }
  private static void printCell(int cell) {
    switch(cell){
      case 0:
        System.out.print(" ");
        break;
      case 1:
        System.out.print("X");
        break;
      case 2:
        System.out.print("O");
        break;
    }
  }
}